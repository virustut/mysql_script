import streamlit as st
import mysql.connector
import pandas as pd
import psutil
import time
import smtplib
from email.mime.text import MIMEText
import os

# ================= CONFIG =================
DB_CONFIG = {
    "host": "192.168.0.104",
    "user": "dba",
    "password": "Feb@2026"   # ⚠️ Change later to env variable
}

ALERT_CPU = 90
ALERT_DISK = 80

EMAIL_SENDER = "your_email@gmail.com"
EMAIL_PASSWORD = "your_password"
EMAIL_RECEIVER = "client_email@gmail.com"

# ================= LOGIN =================
def login():
    st.title("🔐 Login")
    user = st.text_input("Username")
    pwd = st.text_input("Password", type="password")

    if st.button("Login"):
        if user == "admin" and pwd == "admin123":
            st.session_state["login"] = True
        else:
            st.error("Invalid credentials")

if "login" not in st.session_state:
    st.session_state["login"] = False

if not st.session_state["login"]:
    login()
    st.stop()

# ================= DB CONNECTION =================
def get_conn(db=None):
    return mysql.connector.connect(
        host=DB_CONFIG["host"],
        user=DB_CONFIG["user"],
        password=DB_CONFIG["password"],
        database=db
    )

def run_query(query):
    conn = get_conn("information_schema")
    df = pd.read_sql(query, conn)
    conn.close()
    return df

# ================= EMAIL ALERT =================
def send_email(subject, body):
    try:
        msg = MIMEText(body)
        msg["Subject"] = subject
        msg["From"] = EMAIL_SENDER
        msg["To"] = EMAIL_RECEIVER

        server = smtplib.SMTP_SSL("smtp.gmail.com", 465)
        server.login(EMAIL_SENDER, EMAIL_PASSWORD)
        server.sendmail(EMAIL_SENDER, EMAIL_RECEIVER, msg.as_string())
        server.quit()
    except Exception as e:
        print("Email Error:", e)

# ================= PAGE CONFIG =================
st.set_page_config(layout="wide")
st.title("🚀 MySQL Monitoring Dashboard")

# ================= METRICS =================
cpu = psutil.cpu_percent()
memory = psutil.virtual_memory().percent
disk = psutil.disk_usage('/').percent

col1, col2, col3 = st.columns(3)
col1.metric("CPU %", cpu)
col2.metric("Memory %", memory)
col3.metric("Disk %", disk)

# ================= SAVE METRICS =================
try:
    conn = get_conn("monitoring")
    cursor = conn.cursor()

    cursor.execute(
        "INSERT INTO metrics_history (cpu, memory, disk) VALUES (%s,%s,%s)",
        (cpu, memory, disk)
    )

    conn.commit()
    conn.close()
except:
    st.warning("Monitoring DB not found or insert failed")

# ================= PROCESS =================
st.subheader("⚡ Running Queries")

try:
    process = run_query("SHOW FULL PROCESSLIST")
    st.dataframe(process, use_container_width=True)
except:
    st.warning("Process list not available")


# ================= DB SIZE =================
st.subheader("📊 Database Size")

db_df = run_query("""
SELECT 
    table_schema AS db_name,
    ROUND(SUM(data_length+index_length)/1024/1024,2) AS size_mb
FROM information_schema.tables
GROUP BY table_schema
ORDER BY size_mb DESC
""")

st.dataframe(db_df, use_container_width=True)

# ================= SAVE DB SIZE HISTORY =================
try:
    conn = get_conn("monitoring")
    cursor = conn.cursor()

    for _, row in db_df.iterrows():
        cursor.execute(
            "INSERT INTO db_size_history (db_name,size_mb) VALUES (%s,%s)",
            (row["db_name"], row["size_mb"])
        )

    conn.commit()
    conn.close()
except:
    pass

# ================= DB SELECT =================
db_list = db_df["db_name"].tolist()
selected_db = st.selectbox("Select Database", db_list)

# ================= FRAGMENTATION =================
st.subheader("⚠️ Fragmentation")

frag = run_query(f"""
SELECT 
    table_name,
    ROUND(data_length/1024/1024,2) AS data_mb,
    ROUND(index_length/1024/1024,2) AS idx_mb,
    ROUND(data_free/1024/1024,2) AS frag_mb
FROM information_schema.tables 
WHERE table_schema='{selected_db}'
ORDER BY data_free DESC
""")

st.dataframe(frag, use_container_width=True)

# ================= REPLICATION =================
st.subheader("🔁 Replication Status")

try:
    conn = get_conn()
    cursor = conn.cursor(dictionary=True)
    cursor.execute("SHOW SLAVE STATUS")
    rep = cursor.fetchone()
    conn.close()

    if rep:
        st.json(rep)
        if rep.get("Seconds_Behind_Master") and rep["Seconds_Behind_Master"] > 10:
            st.warning("⚠️ Replication Lag Detected")
    else:
        st.info("No Replication Configured")

except Exception as e:
    st.error("Replication check failed")

# ================= ALERTS =================
if cpu > ALERT_CPU:
    st.error("🔥 High CPU Usage!")
    send_email("High CPU Alert", f"CPU is {cpu}%")

if disk > ALERT_DISK:
    st.error("⚠️ Disk Usage High!")
    send_email("Disk Alert", f"Disk usage is {disk}%")

# ================= HISTORICAL =================
st.subheader("📈 Historical CPU / Disk")

try:
    conn = get_conn("monitoring")
    hist = pd.read_sql("""
        SELECT cpu, disk, created_at 
        FROM metrics_history 
        ORDER BY created_at DESC LIMIT 50
    """, conn)
    conn.close()

    hist = hist.sort_values("created_at")
    st.line_chart(hist.set_index("created_at")[["cpu","disk"]])

except:
    st.warning("No historical data available")

# ================= DB GROWTH =================
st.subheader("📈 DB Growth")

try:
    conn = get_conn("monitoring")
    growth = pd.read_sql("""
        SELECT db_name, size_mb, created_at 
        FROM db_size_history
        ORDER BY created_at DESC LIMIT 200
    """, conn)
    conn.close()

    growth = growth.sort_values("created_at")

    pivot = growth.pivot_table(
        index="created_at",
        columns="db_name",
        values="size_mb"
    )

    st.line_chart(pivot)

except:
    st.warning("DB growth data not available")


# ================= AUTO REFRESH =================
time.sleep(10)
st.rerun()