import streamlit as st
from streamlit_autorefresh import st_autorefresh
import paramiko
import mysql.connector
import pandas as pd
import plotly.express as px

# ----------------------------
# AUTO REFRESH
# ----------------------------
st_autorefresh(interval=10000, key="refresh")

# ----------------------------
# PAGE CONFIG
# ----------------------------
st.set_page_config(page_title="MySQL Monitoring Dashboard", layout="wide")

# ----------------------------
# CUSTOM CSS (CARD UI)
# ----------------------------
st.markdown("""
<style>
.card {
    padding: 12px;
    border-radius: 12px;
    background-color: #0e1117;
    border: 1px solid #262730;
    margin-bottom: 10px;
}
.metric {
    font-size: 14px;
    margin-bottom: 4px;
}
h3 {
    font-size: 16px !important;
}
</style>
""", unsafe_allow_html=True)

st.title("🚀 MySQL Multi Server Monitoring")
st.sidebar.info("Created By Ajit Yadav")

# ----------------------------
# SERVER CONFIGURATION
# ----------------------------
servers = {
    "192.168.0.30": {"host": "192.168.0.30","mysql_user": "dba","mysql_password": "appl!c@ti0n","ssh_user": "root","ssh_password": "Op3nSourc3@875"},
    "192.168.0.33": {"host": "192.168.0.33","mysql_user": "dba","mysql_password": "appl!c@ti0n","ssh_user": "root","ssh_password": "Op3nSourc3@875"},
    "172.24.11.82": {"host": "172.24.11.82","mysql_user": "dba","mysql_password": "Opo@1234","ssh_user": "root","ssh_password": "Op3nSourc3@875"},
    "172.24.11.33": {"host": "172.24.11.33","mysql_user": "dba","mysql_password": "Opo@1234","ssh_user": "root","ssh_password": "Op3nSourc3@875"},
    #"172.18.163.64": {"host": "172.18.163.64","mysql_user": "uat","mysql_password": "Uat@875","ssh_user": "root","ssh_password": "Op3nSourc3@875"},
    #"192.192.192.31": {"host": "192.192.192.31","mysql_user": "root","mysql_password": "Opo@1234","ssh_user": "root","ssh_password": "Op3nSourc3@875"},
    #"172.21.11.162": {"host": "172.21.11.162","mysql_user": "wasim","mysql_password": "Gen@1234","ssh_user": "opoadmin","ssh_password": "Opo@1234"}
}

# ----------------------------
# CENTRAL MONITORING DB
# ----------------------------
logdb = mysql.connector.connect(
    host="172.24.11.82",
    user="monitoring",
    password="M0nit0r",
    database="monitoring"
)
log_cursor = logdb.cursor()

# ----------------------------
# LINUX METRICS
# ----------------------------
def get_linux_metrics(host,user,password):

    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(host,username=user,password=password)

    cpu=float(ssh.exec_command("top -bn1 | grep 'Cpu(s)' | awk '{print $2+$4}'")[1].read().decode().strip() or 0)
    ram=float(ssh.exec_command("free | awk '/Mem/ {printf(\"%.2f\", $3/$2*100)}'")[1].read().decode().strip() or 0)
    disk=float(ssh.exec_command("df -h / | tail -1 | awk '{print $5}' | tr -d '%'")[1].read().decode().strip() or 0)

    mysql_cpu=float(ssh.exec_command("ps -C mysqld -o %cpu= | awk '{sum+=$1} END {print sum}'")[1].read().decode().strip() or 0)
    mysql_ram=float(ssh.exec_command("ps -C mysqld -o %mem= | awk '{sum+=$1} END {print sum}'")[1].read().decode().strip() or 0)

    ssh.close()

    return cpu,ram,disk,mysql_cpu,mysql_ram

# ----------------------------
# MYSQL METRICS
# ----------------------------
def fetch_mysql_metrics(cfg):

    conn=mysql.connector.connect(
        host=cfg["host"],
        user=cfg["mysql_user"],
        password=cfg["mysql_password"]
    )

    cur=conn.cursor(dictionary=True)

    cur.execute("SHOW STATUS LIKE 'Threads_connected'")
    mysql_conn=int(cur.fetchone()["Value"])

    role="Single Server"
    replication_status="N/A"
    lag=0
    io="N/A"
    sql="N/A"

    try:
        cur.execute("SHOW REPLICA STATUS")
        rep=cur.fetchone()

        if rep:
            role="Replica"
            lag=rep.get("Seconds_Behind_Source",0)
            io=rep.get("Replica_IO_Running")
            sql=rep.get("Replica_SQL_Running")

            if io=="Yes" and sql=="Yes":
                replication_status="🟢 Healthy"
            else:
                replication_status="🔴 Broken"
        else:
            cur.execute("SHOW MASTER STATUS")
            if cur.fetchone():
                role="Primary"
                replication_status="Primary Server"
    except:
        pass

    conn.close()
    return mysql_conn,role,replication_status,lag,io,sql

# ----------------------------
# GRID DASHBOARD
# ----------------------------
server_list = list(servers.keys())
cols_per_row = 4

for i in range(0, len(server_list), cols_per_row):

    row_servers = server_list[i:i+cols_per_row]
    cols = st.columns(cols_per_row)

    for idx, col in enumerate(cols):

        if idx < len(row_servers):
            server = row_servers[idx]
            cfg = servers[server]

            with col:
                st.markdown('<div class="card">', unsafe_allow_html=True)
                st.markdown(f"### 🖥️ {server}")

                try:
                    cpu, ram, disk, mysql_cpu, mysql_ram = get_linux_metrics(
                        cfg["host"], cfg["ssh_user"], cfg["ssh_password"]
                    )

                    mysql_conn, role, replication_status, lag, io, sql = fetch_mysql_metrics(cfg)

                    # ALERT COLOR
                    cpu_color = "red" if cpu > 80 else "lightgreen"

                    st.markdown(f"""
                    <div class="metric">CPU: <b style="color:{cpu_color}">{cpu}%</b></div>
                    <div class="metric">RAM: <b>{ram}%</b></div>
                    <div class="metric">Disk: <b>{disk}%</b></div>
                    <div class="metric">Conn: <b>{mysql_conn}</b></div>
                    <div class="metric">MySQL CPU: <b>{mysql_cpu}%</b></div>
                    <div class="metric">MySQL RAM: <b>{mysql_ram}%</b></div>
                    <div class="metric">Role: <b>{role}</b></div>
                    <div class="metric">Repl: <b>{replication_status}</b></div>
                    <div class="metric">Lag: <b>{lag}s</b></div>
                    """, unsafe_allow_html=True)

                    # STORE HISTORY
                    insert = """
                    INSERT INTO system_metrics
                    (server_name,cpu_usage,ram_usage,disk_usage,mysql_cpu,mysql_ram,mysql_connection,replication_lag)
                    VALUES(%s,%s,%s,%s,%s,%s,%s,%s)
                    """
                    log_cursor.execute(insert,(server,cpu,ram,disk,mysql_cpu,mysql_ram,mysql_conn,lag))
                    logdb.commit()

                except Exception as e:
                    st.error(f"❌ {str(e)}")

                st.markdown('</div>', unsafe_allow_html=True)

# ----------------------------
# GLOBAL CPU GRAPH
# ----------------------------
st.subheader("📈 CPU Trends (All Servers)")

df=pd.read_sql("""
SELECT captured_at,cpu_usage,server_name
FROM system_metrics
ORDER BY captured_at DESC
LIMIT 500
""",logdb)

df=df.sort_values("captured_at")

fig=px.line(df,x="captured_at",y="cpu_usage",color="server_name")
st.plotly_chart(fig, use_container_width=True)
