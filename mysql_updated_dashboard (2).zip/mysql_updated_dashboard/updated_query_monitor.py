import time
from datetime import datetime

import pandas as pd
import streamlit as st
import mysql.connector
from mysql.connector import Error


# ============================================================
# 🔧 MYSQL CONNECTION - CHANGE THESE VALUES
# ============================================================

MYSQL_HOST = "192.192.192.31"
MYSQL_PORT = 3306
MYSQL_USER = "root"
MYSQL_PASSWORD = "Opo@1234"
MYSQL_DATABASE = ""


# ============================================================
# ⚙️ SETTINGS
# ============================================================

MAX_QUERY_TEXT = 10000


# ============================================================
# STREAMLIT CONFIG
# ============================================================

st.set_page_config(
    page_title="MySQL Query Monitor",
    page_icon="🐬",
    layout="wide"
)


# ============================================================
# SESSION STATE
# ============================================================

if "selected_session_id" not in st.session_state:
    st.session_state.selected_session_id = None

if "auto_refresh" not in st.session_state:
    st.session_state.auto_refresh = True


# ============================================================
# MYSQL CONNECTION
# ============================================================

def get_connection():

    return mysql.connector.connect(
        host=MYSQL_HOST,
        port=MYSQL_PORT,
        user=MYSQL_USER,
        password=MYSQL_PASSWORD,
        database=MYSQL_DATABASE if MYSQL_DATABASE else None,
        connection_timeout=5,
    )


# ============================================================
# MYSQL VERSION
# ============================================================

def get_mysql_version():

    conn = None

    try:

        conn = get_connection()

        cursor = conn.cursor()

        cursor.execute("SELECT VERSION()")

        version = cursor.fetchone()[0]

        cursor.close()

        return version

    except Exception as e:

        return f"Error: {e}"

    finally:

        if conn:
            conn.close()


# ============================================================
# FORMAT DURATION
# ============================================================

def format_duration(seconds):

    seconds = int(seconds)

    if seconds < 60:
        return f"{seconds}s"

    minutes, seconds = divmod(
        seconds,
        60
    )

    if minutes < 60:
        return f"{minutes}m {seconds}s"

    hours, minutes = divmod(
        minutes,
        60
    )

    return f"{hours}h {minutes}m"


# ============================================================
# GET MYSQL SESSIONS
#
# Compatible with:
# MySQL 5.7
# MySQL 8.0
# MySQL 8.4
#
# Includes:
# Running
# Sleeping
# ============================================================

def get_sessions():

    conn = None

    try:

        conn = get_connection()

        query = """
        SELECT
            ID AS session_id,
            USER AS user_name,
            HOST AS host_name,
            DB AS database_name,
            COMMAND AS command_name,
            TIME AS duration_seconds,
            STATE AS state_name,
            INFO AS query_text
        FROM information_schema.PROCESSLIST
        WHERE ID <> CONNECTION_ID()
        ORDER BY
            CASE
                WHEN COMMAND = 'Sleep' THEN 1
                ELSE 0
            END,
            TIME DESC
        """

        cursor = conn.cursor(
            dictionary=True
        )

        cursor.execute(query)

        rows = cursor.fetchall()

        cursor.close()

        df = pd.DataFrame(rows)

        if df.empty:
            return df

        # ----------------------------------------------------
        # Normalize
        # ----------------------------------------------------

        df["session_id"] = pd.to_numeric(
            df["session_id"],
            errors="coerce"
        )

        df["duration_seconds"] = pd.to_numeric(
            df["duration_seconds"],
            errors="coerce"
        ).fillna(0).astype(int)

        df["user_name"] = (
            df["user_name"]
            .fillna("")
            .astype(str)
        )

        df["host_name"] = (
            df["host_name"]
            .fillna("")
            .astype(str)
        )

        df["database_name"] = (
            df["database_name"]
            .fillna("")
            .astype(str)
        )

        df["command_name"] = (
            df["command_name"]
            .fillna("")
            .astype(str)
        )

        df["state_name"] = (
            df["state_name"]
            .fillna("")
            .astype(str)
        )

        df["query_text"] = (
            df["query_text"]
            .fillna("")
            .astype(str)
        )

        # ----------------------------------------------------
        # Approximate Start Time
        # ----------------------------------------------------

        now = datetime.now()

        df["start_time"] = (
            df["duration_seconds"]
            .apply(
                lambda x:
                now - pd.Timedelta(
                    seconds=int(x)
                )
            )
        )

        df["duration"] = (
            df["duration_seconds"]
            .apply(format_duration)
        )

        return df

    except Error as e:

        st.error(
            f"MySQL Error: {e}"
        )

        return pd.DataFrame()

    except Exception as e:

        st.error(
            f"Error: {e}"
        )

        return pd.DataFrame()

    finally:

        if conn:
            conn.close()


# ============================================================
# HEADER
# ============================================================

st.title(
    "🐬 MySQL Live Query Monitor"
)

st.caption(
    "Live Running & Sleeping MySQL Sessions"
)


# ============================================================
# SIDEBAR
# ============================================================

st.sidebar.header(
    "⚙️ Settings"
)


st.session_state.auto_refresh = (
    st.sidebar.checkbox(
        "Auto Refresh",
        value=st.session_state.auto_refresh
    )
)


refresh_seconds = st.sidebar.selectbox(
    "Refresh Interval",
    [1, 2, 5, 10, 30],
    index=1
)


min_duration = st.sidebar.number_input(
    "Minimum Duration (seconds)",
    min_value=0,
    value=0,
    step=1
)


session_status = st.sidebar.selectbox(
    "Session Status",
    [
        "All",
        "Running",
        "Sleeping"
    ]
)


st.sidebar.divider()


st.sidebar.write(
    "### MySQL Connection"
)

st.sidebar.write(
    f"Host: `{MYSQL_HOST}`"
)

st.sidebar.write(
    f"Port: `{MYSQL_PORT}`"
)

st.sidebar.write(
    f"User: `{MYSQL_USER}`"
)


# ============================================================
# MANUAL REFRESH
# ============================================================

if st.sidebar.button(
    "🔄 Refresh Now",
    use_container_width=True
):

    st.rerun()


# ============================================================
# MYSQL VERSION
# ============================================================

mysql_version = get_mysql_version()


if mysql_version.startswith("Error"):

    st.error(
        "❌ MySQL connection failed\n\n"
        + mysql_version
    )

    st.stop()


st.sidebar.success(
    f"MySQL {mysql_version}"
)


# ============================================================
# GET DATA
# ============================================================

df = get_sessions()


# ============================================================
# DURATION FILTER
# ============================================================

if not df.empty:

    df = df[
        df["duration_seconds"]
        >= min_duration
    ]


# ============================================================
# STATUS FILTER
# ============================================================

if not df.empty:

    if session_status == "Running":

        df = df[
            df["command_name"]
            .str.lower()
            != "sleep"
        ]

    elif session_status == "Sleeping":

        df = df[
            df["command_name"]
            .str.lower()
            == "sleep"
        ]


# ============================================================
# SEARCH / FILTER
# ============================================================

st.divider()

f1, f2, f3 = st.columns(
    [2, 1, 1]
)


search_text = f1.text_input(
    "🔍 Search",
    placeholder=(
        "SQL, user, host, database..."
    )
)


if not df.empty:

    database_list = sorted(
        [
            str(x)
            for x in df[
                "database_name"
            ]
            .dropna()
            .unique()
            if str(x)
        ]
    )

    user_list = sorted(
        [
            str(x)
            for x in df[
                "user_name"
            ]
            .dropna()
            .unique()
            if str(x)
        ]
    )

else:

    database_list = []
    user_list = []


selected_database = f2.selectbox(
    "Database",
    ["All"] + database_list
)


selected_user = f3.selectbox(
    "User",
    ["All"] + user_list
)


# ============================================================
# APPLY FILTERS
# ============================================================

filtered_df = df.copy()


if not filtered_df.empty:

    if search_text:

        mask = (
            filtered_df[
                "query_text"
            ]
            .str.contains(
                search_text,
                case=False,
                na=False
            )
            |
            filtered_df[
                "user_name"
            ]
            .str.contains(
                search_text,
                case=False,
                na=False
            )
            |
            filtered_df[
                "host_name"
            ]
            .str.contains(
                search_text,
                case=False,
                na=False
            )
            |
            filtered_df[
                "database_name"
            ]
            .str.contains(
                search_text,
                case=False,
                na=False
            )
        )

        filtered_df = filtered_df[
            mask
        ]


    if selected_database != "All":

        filtered_df = filtered_df[
            filtered_df[
                "database_name"
            ]
            == selected_database
        ]


    if selected_user != "All":

        filtered_df = filtered_df[
            filtered_df[
                "user_name"
            ]
            == selected_user
        ]


# ============================================================
# METRICS
# ============================================================

if filtered_df.empty:

    total_sessions = 0
    running_count = 0
    sleeping_count = 0
    longest_duration = 0

else:

    total_sessions = len(
        filtered_df
    )

    running_count = len(
        filtered_df[
            filtered_df[
                "command_name"
            ]
            .str.lower()
            != "sleep"
        ]
    )

    sleeping_count = len(
        filtered_df[
            filtered_df[
                "command_name"
            ]
            .str.lower()
            == "sleep"
        ]
    )

    longest_duration = int(
        filtered_df[
            "duration_seconds"
        ].max()
    )


# ============================================================
# METRICS DISPLAY
# ============================================================

m1, m2, m3, m4 = st.columns(4)


m1.metric(
    "Total Sessions",
    total_sessions
)


m2.metric(
    "Running Queries",
    running_count
)


m3.metric(
    "Sleeping",
    sleeping_count
)


m4.metric(
    "Longest Duration",
    format_duration(
        longest_duration
    )
)


# ============================================================
# SESSION TABLE
# ============================================================

st.divider()

st.subheader(
    "📋 Running & Sleeping Sessions"
)


if filtered_df.empty:

    st.info(
        "No sessions found."
    )

else:

    table_df = filtered_df[
        [
            "session_id",
            "user_name",
            "host_name",
            "database_name",
            "command_name",
            "state_name",
            "start_time",
            "duration",
            "query_text"
        ]
    ].copy()


    table_df.columns = [
        "Session ID",
        "User",
        "Host",
        "Database",
        "Command",
        "State",
        "Start Time",
        "Duration",
        "Query Text"
    ]


    # --------------------------------------------------------
    # Row Selection
    #
    # User clicks a row.
    # The Session ID from that row becomes selected.
    # --------------------------------------------------------

    event = st.dataframe(
        table_df,
        use_container_width=True,
        hide_index=True,
        on_select="rerun",
        selection_mode="single-row",
        key="session_table",
        column_config={

            "Session ID":
                st.column_config.NumberColumn(
                    "Session ID",
                    width="small"
                ),

            "User":
                st.column_config.TextColumn(
                    "User",
                    width="small"
                ),

            "Host":
                st.column_config.TextColumn(
                    "Host",
                    width="medium"
                ),

            "Database":
                st.column_config.TextColumn(
                    "Database",
                    width="medium"
                ),

            "Command":
                st.column_config.TextColumn(
                    "Command",
                    width="small"
                ),

            "State":
                st.column_config.TextColumn(
                    "State",
                    width="medium"
                ),

            "Start Time":
                st.column_config.DatetimeColumn(
                    "Start Time",
                    format=(
                        "YYYY-MM-DD HH:mm:ss"
                    )
                ),

            "Duration":
                st.column_config.TextColumn(
                    "Duration",
                    width="small"
                ),

            "Query Text":
                st.column_config.TextColumn(
                    "Query Text",
                    width="large"
                ),
        }
    )


    # --------------------------------------------------------
    # Detect selected row
    # --------------------------------------------------------

    if event:

        try:

            selected_rows = (
                event.selection.rows
            )

        except Exception:

            selected_rows = []


        if selected_rows:

            selected_row_index = (
                selected_rows[0]
            )


            selected_session_from_table = int(
                table_df.iloc[
                    selected_row_index
                ]["Session ID"]
            )


            # Save selected Session ID

            st.session_state.selected_session_id = (
                selected_session_from_table
            )


# ============================================================
# SELECTED SESSION
# ============================================================

st.divider()

st.subheader(
    "🔎 Selected Session Details"
)


selected_session_id = (
    st.session_state.selected_session_id
)


# ============================================================
# FIND SELECTED SESSION
# ============================================================

if selected_session_id is not None:

    selected_data = pd.DataFrame()


    if not filtered_df.empty:

        selected_data = filtered_df[
            filtered_df[
                "session_id"
            ]
            == selected_session_id
        ]


    # --------------------------------------------------------
    # SESSION STILL EXISTS
    # --------------------------------------------------------

    if not selected_data.empty:

        selected_row = (
            selected_data.iloc[0]
        )


        # ====================================================
        # TOP INFORMATION
        # ====================================================

        d1, d2, d3, d4 = st.columns(4)


        d1.metric(
            "Session ID",
            str(
                selected_row[
                    "session_id"
                ]
            )
        )


        d2.metric(
            "Command",
            selected_row[
                "command_name"
            ]
        )


        d3.metric(
            "Duration",
            selected_row[
                "duration"
            ]
        )


        d4.metric(
            "User",
            selected_row[
                "user_name"
            ]
        )


        # ====================================================
        # DETAILS
        # ====================================================

        left, right = st.columns(
            [2, 3]
        )


        with left:

            st.write(
                f"**Session ID:** "
                f"{selected_row['session_id']}"
            )


            st.write(
                f"**User:** "
                f"{selected_row['user_name']}"
            )


            st.write(
                f"**Host:** "
                f"{selected_row['host_name']}"
            )


            st.write(
                f"**Database:** "
                f"{selected_row['database_name'] or '-'}"
            )


            st.write(
                f"**Command:** "
                f"{selected_row['command_name']}"
            )


            st.write(
                f"**State:** "
                f"{selected_row['state_name'] or '-'}"
            )


            st.write(
                f"**Start Time:** "
                f"{selected_row['start_time']}"
            )


            st.write(
                f"**Duration:** "
                f"{selected_row['duration']}"
            )


        # ====================================================
        # SQL
        # ====================================================

        with right:

            st.write(
                "### SQL Text"
            )


            query_text = (
                selected_row[
                    "query_text"
                ]
            )


            if len(query_text) > MAX_QUERY_TEXT:

                query_text = (
                    query_text[
                        :MAX_QUERY_TEXT
                    ]
                    + "\n\n... truncated ..."
                )


            if query_text:

                st.code(
                    query_text,
                    language="sql"
                )

            else:

                if (
                    str(
                        selected_row[
                            "command_name"
                        ]
                    ).lower()
                    == "sleep"
                ):

                    st.info(
                        "💤 This session is "
                        "currently sleeping. "
                        "There is no active SQL "
                        "statement."
                    )

                else:

                    st.info(
                        "No SQL text available."
                    )


    # --------------------------------------------------------
    # SESSION DISAPPEARED
    # --------------------------------------------------------

    else:

        st.warning(
            f"⚠️ Session "
            f"{selected_session_id} "
            f"is no longer available."
        )

        st.info(
            "The query may have completed, "
            "the connection may have closed, "
            "or the current filters may "
            "be hiding this session."
        )


else:

    st.info(
        "👆 Click any row in the table above "
        "to view its session details."
    )


# ============================================================
# FOOTER
# ============================================================

st.divider()

st.caption(
    "Last refresh: "
    + datetime.now().strftime(
        "%Y-%m-%d %H:%M:%S"
    )
)


# ============================================================
# AUTO REFRESH
# ============================================================

if st.session_state.auto_refresh:

    time.sleep(
        refresh_seconds
    )

    st.rerun()