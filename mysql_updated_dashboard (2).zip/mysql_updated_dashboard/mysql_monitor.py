import time
from datetime import datetime

import pandas as pd
import streamlit as st
import mysql.connector
from mysql.connector import Error


# ============================================================
# 🔧 MYSQL CONNECTION - CHANGE THESE VALUES
# ============================================================

MYSQL_HOST = "192.192.192.31"
MYSQL_PORT = 3306
MYSQL_USER = "root"
MYSQL_PASSWORD = "Opo@1234"
MYSQL_DATABASE = ""


# ============================================================
# ⚙️ SETTINGS
# ============================================================

MAX_QUERY_TEXT = 10000


# ============================================================
# STREAMLIT CONFIG
# ============================================================

st.set_page_config(
    page_title="MySQL Query Monitor",
    page_icon="🐬",
    layout="wide"
)


# ============================================================
# SESSION STATE INITIALIZATION
# ============================================================

if "selected_session_id" not in st.session_state:
    st.session_state.selected_session_id = None

if "auto_refresh" not in st.session_state:
    st.session_state.auto_refresh = True


# ============================================================
# DATABASE CONNECTION
# ============================================================

def get_connection():

    return mysql.connector.connect(
        host=MYSQL_HOST,
        port=MYSQL_PORT,
        user=MYSQL_USER,
        password=MYSQL_PASSWORD,
        database=MYSQL_DATABASE if MYSQL_DATABASE else None,
        connection_timeout=5,
    )


# ============================================================
# MYSQL VERSION
# ============================================================

def get_mysql_version():

    conn = None

    try:

        conn = get_connection()

        cursor = conn.cursor()

        cursor.execute("SELECT VERSION()")

        version = cursor.fetchone()[0]

        cursor.close()

        return version

    except Exception as e:

        return f"Error: {e}"

    finally:

        if conn:
            conn.close()


# ============================================================
# GET MYSQL SESSIONS
#
# MySQL 5.7 / 8.0 / 8.4
#
# Includes:
#   Running queries
#   Sleeping sessions
# ============================================================

def get_sessions():

    conn = None

    try:

        conn = get_connection()

        query = """
        SELECT
            ID AS session_id,
            USER AS user_name,
            HOST AS host_name,
            DB AS database_name,
            COMMAND AS command_name,
            TIME AS duration_seconds,
            STATE AS state_name,
            INFO AS query_text
        FROM information_schema.PROCESSLIST
        WHERE ID <> CONNECTION_ID()
        ORDER BY
            CASE
                WHEN COMMAND = 'Sleep' THEN 1
                ELSE 0
            END,
            TIME DESC
        """

        cursor = conn.cursor(dictionary=True)

        cursor.execute(query)

        rows = cursor.fetchall()

        cursor.close()

        df = pd.DataFrame(rows)

        if df.empty:
            return df

        # ----------------------------------------------------
        # Normalize values
        # ----------------------------------------------------

        df["session_id"] = pd.to_numeric(
            df["session_id"],
            errors="coerce"
        ).astype("Int64")

        df["duration_seconds"] = pd.to_numeric(
            df["duration_seconds"],
            errors="coerce"
        ).fillna(0).astype(int)

        df["query_text"] = (
            df["query_text"]
            .fillna("")
            .astype(str)
        )

        df["command_name"] = (
            df["command_name"]
            .fillna("")
            .astype(str)
        )

        df["state_name"] = (
            df["state_name"]
            .fillna("")
            .astype(str)
        )

        # ----------------------------------------------------
        # Approximate start time
        # ----------------------------------------------------

        now = datetime.now()

        df["start_time"] = df[
            "duration_seconds"
        ].apply(
            lambda x:
            now - pd.Timedelta(
                seconds=int(x)
            )
        )

        df["duration"] = df[
            "duration_seconds"
        ].apply(
            format_duration
        )

        return df

    except Error as e:

        st.error(
            f"MySQL Error: {e}"
        )

        return pd.DataFrame()

    except Exception as e:

        st.error(
            f"Error: {e}"
        )

        return pd.DataFrame()

    finally:

        if conn:

            conn.close()


# ============================================================
# FORMAT DURATION
# ============================================================

def format_duration(seconds):

    seconds = int(seconds)

    if seconds < 60:
        return f"{seconds}s"

    minutes, seconds = divmod(
        seconds,
        60
    )

    if minutes < 60:
        return f"{minutes}m {seconds}s"

    hours, minutes = divmod(
        minutes,
        60
    )

    return f"{hours}h {minutes}m"


# ============================================================
# KILL QUERY
# ============================================================

def kill_query(session_id):

    conn = None

    try:

        conn = get_connection()

        cursor = conn.cursor()

        session_id = int(session_id)

        cursor.execute(
            f"KILL QUERY {session_id}"
        )

        conn.commit()

        cursor.close()

        return True, (
            f"Query {session_id} "
            f"killed successfully."
        )

    except Error as e:

        return False, str(e)

    except Exception as e:

        return False, str(e)

    finally:

        if conn:
            conn.close()


# ============================================================
# KILL CONNECTION
# ============================================================

def kill_connection(session_id):

    conn = None

    try:

        conn = get_connection()

        cursor = conn.cursor()

        session_id = int(session_id)

        cursor.execute(
            f"KILL CONNECTION {session_id}"
        )

        conn.commit()

        cursor.close()

        return True, (
            f"Connection {session_id} "
            f"killed successfully."
        )

    except Error as e:

        return False, str(e)

    except Exception as e:

        return False, str(e)

    finally:

        if conn:
            conn.close()


# ============================================================
# HEADER
# ============================================================

st.title(
    "🐬 MySQL Live Query Monitor"
)

st.caption(
    "MySQL 5.7 / 8.x — Live Sessions & Queries"
)


# ============================================================
# SIDEBAR
# ============================================================

st.sidebar.header(
    "⚙️ Settings"
)


st.session_state.auto_refresh = (
    st.sidebar.checkbox(
        "Auto Refresh",
        value=st.session_state.auto_refresh
    )
)


refresh_seconds = st.sidebar.selectbox(
    "Refresh Interval",
    [1, 2, 5, 10, 30],
    index=1
)


min_duration = st.sidebar.number_input(
    "Minimum Duration (seconds)",
    min_value=0,
    value=0,
    step=1
)


session_status = st.sidebar.selectbox(
    "Session Status",
    [
        "All",
        "Running",
        "Sleeping"
    ]
)


st.sidebar.divider()


st.sidebar.write(
    "MySQL Connection"
)


st.sidebar.write(
    f"Host: `{MYSQL_HOST}`"
)


st.sidebar.write(
    f"Port: `{MYSQL_PORT}`"
)


st.sidebar.write(
    f"User: `{MYSQL_USER}`"
)


# ============================================================
# MANUAL REFRESH
# ============================================================

if st.sidebar.button(
    "🔄 Refresh Now",
    use_container_width=True
):

    st.rerun()


# ============================================================
# MYSQL VERSION
# ============================================================

mysql_version = get_mysql_version()


if mysql_version.startswith(
    "Error"
):

    st.error(
        "❌ MySQL connection failed\n\n"
        + mysql_version
    )

    st.stop()


st.sidebar.success(
    f"MySQL {mysql_version}"
)


# ============================================================
# GET SESSIONS
# ============================================================

df = get_sessions()


# ============================================================
# DURATION FILTER
# ============================================================

if not df.empty:

    df = df[
        df["duration_seconds"]
        >= min_duration
    ]


# ============================================================
# STATUS FILTER
# ============================================================

if not df.empty:

    if session_status == "Running":

        df = df[
            df["command_name"]
            .str.lower()
            != "sleep"
        ]

    elif session_status == "Sleeping":

        df = df[
            df["command_name"]
            .str.lower()
            == "sleep"
        ]


# ============================================================
# METRICS
# ============================================================

if df.empty:

    total_sessions = 0
    running_count = 0
    sleeping_count = 0
    longest_duration = 0

else:

    total_sessions = len(df)

    running_count = len(
        df[
            df["command_name"]
            .str.lower()
            != "sleep"
        ]
    )

    sleeping_count = len(
        df[
            df["command_name"]
            .str.lower()
            == "sleep"
        ]
    )

    longest_duration = int(
        df["duration_seconds"].max()
    )


col1, col2, col3, col4 = st.columns(4)


col1.metric(
    "Total Sessions",
    total_sessions
)


col2.metric(
    "Running Queries",
    running_count
)


col3.metric(
    "Sleeping",
    sleeping_count
)


col4.metric(
    "Longest Duration",
    format_duration(
        longest_duration
    )
)


# ============================================================
# SEARCH
# ============================================================

st.divider()


f1, f2, f3 = st.columns(
    [2, 1, 1]
)


search_text = f1.text_input(
    "🔍 Search",
    placeholder=(
        "SQL, user, host, database..."
    )
)


if not df.empty:

    database_list = sorted(
        [
            str(x)
            for x in df[
                "database_name"
            ]
            .dropna()
            .unique()
        ]
    )

    user_list = sorted(
        [
            str(x)
            for x in df[
                "user_name"
            ]
            .dropna()
            .unique()
        ]
    )

else:

    database_list = []
    user_list = []


selected_database = f2.selectbox(
    "Database",
    ["All"] + database_list
)


selected_user = f3.selectbox(
    "User",
    ["All"] + user_list
)


# ============================================================
# APPLY FILTERS
# ============================================================

filtered_df = df.copy()


if not filtered_df.empty:

    if search_text:

        mask = (
            filtered_df[
                "query_text"
            ]
            .str.contains(
                search_text,
                case=False,
                na=False
            )
            |
            filtered_df[
                "user_name"
            ]
            .fillna("")
            .str.contains(
                search_text,
                case=False,
                na=False
            )
            |
            filtered_df[
                "host_name"
            ]
            .fillna("")
            .str.contains(
                search_text,
                case=False,
                na=False
            )
            |
            filtered_df[
                "database_name"
            ]
            .fillna("")
            .str.contains(
                search_text,
                case=False,
                na=False
            )
        )

        filtered_df = filtered_df[
            mask
        ]


    if selected_database != "All":

        filtered_df = filtered_df[
            filtered_df[
                "database_name"
            ]
            == selected_database
        ]


    if selected_user != "All":

        filtered_df = filtered_df[
            filtered_df[
                "user_name"
            ]
            == selected_user
        ]


# ============================================================
# CURRENT SESSION IDS
# ============================================================

current_session_ids = []

if not filtered_df.empty:

    current_session_ids = [
        int(x)
        for x in filtered_df[
            "session_id"
        ]
        .dropna()
        .tolist()
    ]


# ============================================================
# IMPORTANT:
# PRESERVE SELECTED SESSION
# ============================================================

previous_session = (
    st.session_state.selected_session_id
)


# If previously selected session still exists,
# DON'T change it.

if (
    previous_session is not None
    and previous_session in current_session_ids
):

    selected_session = previous_session


# If there is no previous selection,
# select first session only once.

elif (
    previous_session is None
    and current_session_ids
):

    selected_session = current_session_ids[0]

    st.session_state.selected_session_id = (
        selected_session
    )


# If previous session disappeared,
# don't automatically jump to another session.

else:

    selected_session = None


# ============================================================
# RUNNING TABLE
# ============================================================

st.subheader(
    "🔴 Currently Running / Sleeping Sessions"
)


if filtered_df.empty:

    st.info(
        "No matching sessions found."
    )

else:

    display_df = filtered_df[
        [
            "session_id",
            "user_name",
            "host_name",
            "database_name",
            "command_name",
            "state_name",
            "start_time",
            "duration",
            "query_text"
        ]
    ].copy()


    display_df.columns = [
        "Session ID",
        "User",
        "Host",
        "Database",
        "Command",
        "State",
        "Start Time",
        "Duration",
        "Query Text"
    ]


    st.dataframe(
        display_df,
        use_container_width=True,
        hide_index=True,
        column_config={

            "Session ID":
                st.column_config.NumberColumn(
                    "Session ID"
                ),

            "Query Text":
                st.column_config.TextColumn(
                    "Query Text",
                    width="large"
                ),

            "Start Time":
                st.column_config.DatetimeColumn(
                    "Start Time",
                    format=(
                        "YYYY-MM-DD HH:mm:ss"
                    )
                )
        }
    )


# ============================================================
# SELECTED SESSION DETAILS
# ============================================================

st.divider()

st.subheader(
    "🔎 Selected Session Details"
)


# ------------------------------------------------------------
# If selected session still exists
# ------------------------------------------------------------

if (
    selected_session is not None
    and not filtered_df.empty
):

    selected_rows = filtered_df[
        filtered_df[
            "session_id"
        ]
        == selected_session
    ]


    if not selected_rows.empty:

        selected_row = (
            selected_rows.iloc[0]
        )


        # ====================================================
        # SESSION SELECTOR
        #
        # KEY POINT:
        # We use the current selected session
        # as the default value.
        # ====================================================

        session_options = current_session_ids


        if selected_session in session_options:

            selected_index = (
                session_options.index(
                    selected_session
                )
            )

        else:

            selected_index = 0


        selected_from_dropdown = (
            st.selectbox(
                "Select Session ID",
                session_options,
                index=selected_index,
                key="session_dropdown"
            )
        )


        # ----------------------------------------------------
        # Detect manual change
        # ----------------------------------------------------

        if (
            selected_from_dropdown
            != st.session_state.selected_session_id
        ):

            st.session_state.selected_session_id = (
                selected_from_dropdown
            )

            # Re-run immediately so details change
            # without waiting for next refresh.

            st.rerun()


        # ====================================================
        # DETAILS
        # ====================================================

        # Get latest row again based on selected ID

        selected_rows = filtered_df[
            filtered_df[
                "session_id"
            ]
            == st.session_state.selected_session_id
        ]


        if not selected_rows.empty:

            selected_row = (
                selected_rows.iloc[0]
            )


            col_left, col_right = st.columns(
                [4, 1]
            )


            # =================================================
            # INFORMATION
            # =================================================

            with col_left:

                a, b, c = st.columns(3)


                a.metric(
                    "Session ID",
                    str(
                        selected_row[
                            "session_id"
                        ]
                    )
                )


                b.metric(
                    "Command",
                    selected_row[
                        "command_name"
                    ]
                )


                c.metric(
                    "Duration",
                    selected_row[
                        "duration"
                    ]
                )


                st.write(
                    f"**User:** "
                    f"{selected_row['user_name']}"
                )


                st.write(
                    f"**Host:** "
                    f"{selected_row['host_name']}"
                )


                st.write(
                    f"**Database:** "
                    f"{selected_row['database_name']}"
                )


                st.write(
                    f"**State:** "
                    f"{selected_row['state_name'] or '-'}"
                )


                st.write(
                    f"**Start Time:** "
                    f"{selected_row['start_time']}"
                )


                st.write("### SQL")


                query_text = selected_row[
                    "query_text"
                ]


                if len(query_text) > MAX_QUERY_TEXT:

                    query_text = (
                        query_text[
                            :MAX_QUERY_TEXT
                        ]
                        + "\n\n... truncated ..."
                    )


                if query_text:

                    st.code(
                        query_text,
                        language="sql"
                    )

                else:

                    if (
                        selected_row[
                            "command_name"
                        ].lower()
                        == "sleep"
                    ):

                        st.info(
                            "💤 This session is "
                            "currently sleeping. "
                            "There is no active SQL "
                            "statement."
                        )

                    else:

                        st.info(
                            "No SQL text available."
                        )


            # =================================================
            # ACTION
            # =================================================

            with col_right:

                command = str(
                    selected_row[
                        "command_name"
                    ]
                ).lower()


                if command == "sleep":

                    st.warning(
                        "💤 Sleeping Session"
                    )


                    st.write(
                        "KILL CONNECTION will "
                        "terminate the complete "
                        "connection."
                    )


                    if st.button(
                        "🔴 KILL CONNECTION",
                        type="primary",
                        use_container_width=True
                    ):

                        success, message = (
                            kill_connection(
                                st.session_state
                                .selected_session_id
                            )
                        )


                        if success:

                            st.success(
                                message
                            )

                            time.sleep(1)

                            st.rerun()

                        else:

                            st.error(
                                message
                            )


                else:

                    st.warning(
                        "🔥 Running Query"
                    )


                    st.write(
                        "This will stop only "
                        "the current query."
                    )


                    if st.button(
                        "🔴 KILL QUERY",
                        type="primary",
                        use_container_width=True
                    ):

                        success, message = (
                            kill_query(
                                st.session_state
                                .selected_session_id
                            )
                        )


                        if success:

                            st.success(
                                message
                            )

                            time.sleep(1)

                            st.rerun()

                        else:

                            st.error(
                                message
                            )


# ============================================================
# SELECTED SESSION DISAPPEARED
# ============================================================

elif (
    st.session_state.selected_session_id
    is not None
):

    st.warning(
        f"⚠️ Session "
        f"{st.session_state.selected_session_id} "
        f"is no longer available."
    )

    st.info(
        "The query may have completed, "
        "the connection may have closed, "
        "or the current filters may be hiding it."
    )


else:

    st.info(
        "No session selected."
    )


# ============================================================
# FOOTER
# ============================================================

st.divider()

st.caption(
    "Last refresh: "
    + datetime.now().strftime(
        "%Y-%m-%d %H:%M:%S"
    )
)


# ============================================================
# AUTO REFRESH
# ============================================================

if st.session_state.auto_refresh:

    time.sleep(
        refresh_seconds
    )

    st.rerun()
