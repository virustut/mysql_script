import streamlit as st
from streamlit_autorefresh import st_autorefresh
import paramiko
import mysql.connector
import pandas as pd
import plotly.express as px

# ----------------------------
# AUTO REFRESH
# ----------------------------
st_autorefresh(interval=10000, key="refresh")

# ----------------------------
# SERVER CONFIGURATION
# ----------------------------
servers = {
    "192.168.0.30": {"host": "192.168.0.30","mysql_user": "dba","mysql_password": "appl!c@ti0n","ssh_user": "root","ssh_password": "Op3nSourc3@875"},
    "192.168.0.33": {"host": "192.168.0.33","mysql_user": "dba","mysql_password": "appl!c@ti0n","ssh_user": "root","ssh_password": "Op3nSourc3@875"},
    "172.24.11.82": {"host": "172.24.11.82","mysql_user": "dba","mysql_password": "Opo@1234","ssh_user": "root","ssh_password": "Op3nSourc3@875"},
    "172.24.11.33": {"host": "172.24.11.33","mysql_user": "dba","mysql_password": "Opo@1234","ssh_user": "root","ssh_password": "Op3nSourc3@875"},
    "172.18.163.64": {"host": "172.18.163.64","mysql_user": "uat","mysql_password": "Uat@875","ssh_user": "root","ssh_password": "Op3nSourc3@875"},
    "192.192.192.31": {"host": "192.192.192.31","mysql_user": "root","mysql_password": "Opo@1234","ssh_user": "root","ssh_password": "Op3nSourc3@875"},
    "172.21.11.162": {"host": "172.21.11.162","mysql_user": "wasim","mysql_password": "Gen@1234","ssh_user": "opoadmin","ssh_password": "Opo@1234"}
}

# ----------------------------
# CENTRAL MONITORING DB
# ----------------------------
logdb = mysql.connector.connect(
    host="172.24.11.82",
    user="monitoring",
    password="M0nit0r",
    database="monitoring"
)

log_cursor = logdb.cursor()

# ----------------------------
# STREAMLIT UI
# ----------------------------
st.set_page_config(page_title="MySQL Monitoring Dashboard", layout="wide")
st.title("🚀 MySQL Multi Server Monitoring")

selected_server = st.sidebar.selectbox("Select Server", list(servers.keys()))
st.sidebar.info("Created By Ajit Yadav")

# ----------------------------
# LINUX METRICS
# ----------------------------
def get_linux_metrics(host,user,password):

    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    ssh.connect(host,username=user,password=password)

    cpu=float(ssh.exec_command("top -bn1 | grep 'Cpu(s)' | awk '{print $2+$4}'")[1].read().decode().strip() or 0)
    ram=float(ssh.exec_command("free | awk '/Mem/ {printf(\"%.2f\", $3/$2*100)}'")[1].read().decode().strip() or 0)
    disk=float(ssh.exec_command("df -h / | tail -1 | awk '{print $5}' | tr -d '%'")[1].read().decode().strip() or 0)

    mysql_cpu=float(ssh.exec_command("ps -C mysqld -o %cpu= | awk '{sum+=$1} END {print sum}'")[1].read().decode().strip() or 0)
    mysql_ram=float(ssh.exec_command("ps -C mysqld -o %mem= | awk '{sum+=$1} END {print sum}'")[1].read().decode().strip() or 0)

    ssh.close()

    return cpu,ram,disk,mysql_cpu,mysql_ram


# ----------------------------
# MYSQL METRICS
# ----------------------------
def fetch_mysql_metrics(cfg):

    conn=mysql.connector.connect(
        host=cfg["host"],
        user=cfg["mysql_user"],
        password=cfg["mysql_password"]
    )

    cur=conn.cursor(dictionary=True)

    cur.execute("SHOW STATUS LIKE 'Threads_connected'")
    mysql_conn=int(cur.fetchone()["Value"])

    role="Single Server"
    replication_status="N/A"
    lag=0
    io="N/A"
    sql="N/A"

    try:

        cur.execute("SHOW REPLICA STATUS")
        rep=cur.fetchone()

        if rep:

            role="Replica"

            lag=rep.get("Seconds_Behind_Source",0)
            io=rep.get("Replica_IO_Running")
            sql=rep.get("Replica_SQL_Running")

            if io=="Yes" and sql=="Yes":
                replication_status="🟢 Healthy"
            else:
                replication_status="🔴 Broken"

        else:

            cur.execute("SHOW MASTER STATUS")

            if cur.fetchone():
                role="Primary"
                replication_status="Primary Server"

    except:
        pass

    conn.close()

    return mysql_conn,role,replication_status,lag,io,sql


# ----------------------------
# PROCESSLIST
# ----------------------------
def get_processlist(cfg):

    conn=mysql.connector.connect(
        host=cfg["host"],
        user=cfg["mysql_user"],
        password=cfg["mysql_password"]
    )

    df=pd.read_sql("""
        SELECT ID,USER,HOST,DB,TIME,STATE,INFO
        FROM information_schema.PROCESSLIST
        WHERE COMMAND!='Sleep'
        ORDER BY TIME DESC
        LIMIT 20
    """,conn)

    conn.close()

    return df.astype(str)


# ----------------------------
# DEADLOCK
# ----------------------------
def get_deadlocks(cfg):

    conn=mysql.connector.connect(
        host=cfg["host"],
        user=cfg["mysql_user"],
        password=cfg["mysql_password"]
    )

    cur=conn.cursor()

    cur.execute("SHOW ENGINE INNODB STATUS")

    result=cur.fetchone()[2]

    conn.close()

    if "LATEST DETECTED DEADLOCK" in result:
        return result.split("LATEST DETECTED DEADLOCK")[1][:1000]

    return "No Deadlocks Detected"


# ----------------------------
# ROW LOCK WAITS
# ----------------------------
def row_lock_waits(cfg):

    conn=mysql.connector.connect(
        host=cfg["host"],
        user=cfg["mysql_user"],
        password=cfg["mysql_password"]
    )

    df=pd.read_sql("""
        SELECT *
        FROM performance_schema.data_lock_waits
        LIMIT 20
    """,conn)

    conn.close()

    return df.astype(str)


# ----------------------------
# FETCH METRICS
# ----------------------------
cfg=servers[selected_server]

cpu,ram,disk,mysql_cpu,mysql_ram=get_linux_metrics(cfg["host"],cfg["ssh_user"],cfg["ssh_password"])

mysql_conn,role,replication_status,lag,io,sql=fetch_mysql_metrics(cfg)

# ----------------------------
# METRICS DISPLAY
# ----------------------------
c1,c2,c3,c4=st.columns(4)

c1.metric("CPU",f"{cpu}%")
c2.metric("RAM",f"{ram}%")
c3.metric("Disk",f"{disk}%")
c4.metric("MySQL Connections",mysql_conn)

c5,c6=st.columns(2)

c5.metric("MySQL CPU",f"{mysql_cpu}%")
c6.metric("MySQL RAM",f"{mysql_ram}%")

st.subheader("Replication Status")

r1,r2,r3,r4,r5=st.columns(5)

r1.metric("Role",role)
r2.metric("Replication",replication_status)
r3.metric("Lag",f"{lag} sec")
r4.metric("IO Thread",io)
r5.metric("SQL Thread",sql)

# ----------------------------
# STORE HISTORY
# ----------------------------
insert="""
INSERT INTO system_metrics
(server_name,cpu_usage,ram_usage,disk_usage,mysql_cpu,mysql_ram,mysql_connection,replication_lag)
VALUES(%s,%s,%s,%s,%s,%s,%s,%s)
"""

log_cursor.execute(insert,(selected_server,cpu,ram,disk,mysql_cpu,mysql_ram,mysql_conn,lag))
logdb.commit()

# ----------------------------
# DEADLOCK DETECTION
# ----------------------------
st.subheader("Deadlock Detection")
st.code(get_deadlocks(cfg))

# ----------------------------
# ROW LOCK WAITS
# ----------------------------
st.subheader("InnoDB Row Lock Waits")

locks=row_lock_waits(cfg)

if not locks.empty:
    st.dataframe(locks,width="stretch")
else:
    st.success("No Row Lock Waits")

# ----------------------------
# RUNNING QUERIES
# ----------------------------
st.subheader("Running Queries")

proc=get_processlist(cfg)

if not proc.empty:

    header=st.columns([1,2,3,2,1,3])

    header[0].write("ID")
    header[1].write("USER")
    header[2].write("HOST")
    header[3].write("DB")
    header[4].write("TIME")
    header[5].write("QUERY")

    for i,row in proc.iterrows():

        cols=st.columns([1,2,3,2,1,3])

        cols[0].write(row["ID"])
        cols[1].write(row["USER"])
        cols[2].write(row["HOST"])
        cols[3].write(row["DB"])
        cols[4].write(row["TIME"])
        cols[5].write(str(row["INFO"])[:100])

else:
    st.success("No Active Queries")


# ----------------------------
# HISTORY GRAPH
# ----------------------------
df=pd.read_sql(f"""
SELECT captured_at,cpu_usage,ram_usage,replication_lag
FROM system_metrics
WHERE server_name='{selected_server}'
ORDER BY captured_at DESC
LIMIT 200
""",logdb)

df=df.sort_values("captured_at")

st.subheader("CPU Usage")

fig=px.line(df,x="captured_at",y="cpu_usage")
st.plotly_chart(fig, width="stretch")

st.subheader("Replication Lag")

fig2=px.line(df,x="captured_at",y="replication_lag")
st.plotly_chart(fig2, width="stretch")


